"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const admin = __importStar(require("firebase-admin"));
let db;
let initialized = false;
function initFirebase() {
    if (!initialized) {
        const serviceAccountJson = process.env.FIREBASE_SERVICE_ACCOUNT;
        if (!serviceAccountJson)
            throw new Error('Missing FIREBASE_SERVICE_ACCOUNT');
        const serviceAccount = JSON.parse(serviceAccountJson);
        admin.initializeApp({
            credential: admin.credential.cert(serviceAccount),
        });
        db = admin.firestore();
        initialized = true;
    }
}
function getTodayDate() {
    return new Date().toISOString().split('T')[0]; // 'YYYY-MM-DD'
}
function generateSVG(todayHits, totalHits) {
    return `
    <svg xmlns="http://www.w3.org/2000/svg" width="200" height="20" role="img" aria-label="Hits">
      <linearGradient id="bg" x2="0" y2="100%">
        <stop offset="0" stop-color="#444" stop-opacity=".1"/>
        <stop offset="1" stop-opacity=".1"/>
      </linearGradient>
      <rect rx="3" width="200" height="20" fill="#555"/>
      <rect rx="3" x="70" width="130" height="20" fill="#007ec6"/>
      <rect rx="3" width="200" height="20" fill="url(#bg)"/>
      <g fill="#fff" text-anchor="middle" font-family="Verdana,Geneva,DejaVu Sans,sans-serif" font-size="11">
        <text x="35" y="14">Hits</text>
        <text x="130" y="14">Today: ${todayHits} | Total: ${totalHits}</text>
      </g>
    </svg>`;
}
const handler = (event) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b;
    try {
        initFirebase();
        const postId = (_a = event.queryStringParameters) === null || _a === void 0 ? void 0 : _a.post_id;
        if (!postId) {
            return {
                statusCode: 400,
                body: 'Missing post_id',
            };
        }
        const domain = (_b = event.queryStringParameters) === null || _b === void 0 ? void 0 : _b.domain;
        if (!domain) {
            return {
                statusCode: 400,
                body: 'Missing domain',
            };
        }
        const docRef = db.collection('beenslab').doc(domain).collection('posts').doc(postId);
        const today = getTodayDate();
        let totalHits = 1;
        let todayHits = 1;
        yield db.runTransaction((t) => __awaiter(void 0, void 0, void 0, function* () {
            const doc = yield t.get(docRef);
            const data = doc.exists ? doc.data() || {} : {};
            const prevTotal = data.total_hits || 0;
            const prevToday = data.today_hits || 0;
            const lastDate = data.last_hits_date || '';
            totalHits = prevTotal + 1;
            todayHits = (lastDate === today) ? (prevToday + 1) : 1;
            t.set(docRef, {
                total_hits: totalHits,
                today_hits: todayHits,
                last_hits_date: today,
            }, { merge: true });
        }));
        const svg = generateSVG(todayHits, totalHits);
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'image/svg+xml',
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'Pragma': 'no-cache',
                'Expires': '0',
            },
            body: svg,
        };
    }
    catch (err) {
        console.error('Error in counter:', err);
        return {
            statusCode: 500,
            body: 'Internal Server Error',
        };
    }
});
exports.handler = handler;
